package Interface;

import Enum.Parent;

public interface Think {
    void think(Parent who);
}
