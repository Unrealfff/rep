package Interface;

public interface Afraid {
    void afraid();
}

