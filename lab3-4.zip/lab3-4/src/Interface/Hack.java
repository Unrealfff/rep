package Interface;

import Enum.Attempt;

public interface Hack {
     void hack(Attempt attempt);
}
