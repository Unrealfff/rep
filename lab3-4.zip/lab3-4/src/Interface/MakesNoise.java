package Interface;

public interface MakesNoise {
    void makesNoise();
}
