package Interface;

import Other.Phone;

public interface PhoneCall {
     void phoneCall(Phone toPhone);
}
