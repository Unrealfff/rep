package Interface;

import Character.*;

public interface Action {
    void action(People toPeople);
}
